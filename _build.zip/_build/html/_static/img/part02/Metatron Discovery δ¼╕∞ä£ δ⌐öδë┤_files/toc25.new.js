(function() {
var toc =  [{"type":"item","name":"5.2.1 Composition of the data column list","url":"metatron_3.0_Discovery/xml/072_Compositionofdatacolumnlist.html"},{"type":"item","name":"5.2.2 Add a custom column","url":"metatron_3.0_Discovery/xml/073_Addacustomcolumn.html"},{"type":"item","name":"5.2.3 Dimensions and measures","url":"metatron_3.0_Discovery/xml/074_Dimensionandmeasure.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();