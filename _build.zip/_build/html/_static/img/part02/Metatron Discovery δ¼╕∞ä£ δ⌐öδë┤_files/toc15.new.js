(function() {
var toc =  [{"type":"item","name":"5.2.1 Job log home","url":"metatron_3.0_Discovery/xml/039_Jobloghome.html"},{"type":"item","name":"5.2.2 Job log details","url":"metatron_3.0_Discovery/xml/040_Joblogdetails.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();