(function() {
var toc =  [{"type":"item","name":"1. Workbench overview","url":"metatron_3.0_Discovery/xml/095_WorkbenchOutline.html"},{"type":"item","name":"2. Create a workbench","url":"metatron_3.0_Discovery/xml/096_CreateaWorkbench.html"},{"type":"book","name":"3. Use a workbench","key":"toc32","url":"metatron_3.0_Discovery/xml/097_UtilizeaWorkbench.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();