(function() {
var toc =  [{"type":"item","name":"1. Features of Metatron Discovery","url":"metatron_3.0_Discovery/xml/002_AdvantagesofmetatronDiscovery.html"},{"type":"item","name":"2. Metatron Discovery structure","url":"metatron_3.0_Discovery/xml/003_StructureofmetatronDiscovery.html"},{"type":"book","name":"3. Relational OLAP vs. multidimensional OLAP","key":"toc2","url":"metatron_3.0_Discovery/xml/004_RelationalOLAPvsMultidimensionalOLAP.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();