(function() {
var toc =  [{"type":"book","name":"3.1 Dataset","key":"toc8","url":"metatron_3.0_Discovery/xml/018_Dataset.html"},{"type":"book","name":"3.2 Dataflow","key":"toc9","url":"metatron_3.0_Discovery/xml/022_Dataflow.html"},{"type":"book","name":"3.3 Data snapshot","key":"toc10","url":"metatron_3.0_Discovery/xml/028_Datasnapshot.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();