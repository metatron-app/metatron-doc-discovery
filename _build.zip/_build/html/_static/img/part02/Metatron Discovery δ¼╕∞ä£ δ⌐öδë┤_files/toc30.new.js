(function() {
var toc =  [{"type":"item","name":"4.1 Notebook details page","url":"metatron_3.0_Discovery/xml/091_Detailednotebooksearch.html"},{"type":"item","name":"4.2 Notebook coding","url":"metatron_3.0_Discovery/xml/092_Notebookcoding.html"},{"type":"item","name":"4.3 Register a notebook API","url":"metatron_3.0_Discovery/xml/093_RegisteranotebookAPI.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();