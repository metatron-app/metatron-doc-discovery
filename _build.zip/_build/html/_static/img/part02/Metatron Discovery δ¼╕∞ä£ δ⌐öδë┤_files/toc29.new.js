(function() {
var toc =  [{"type":"item","name":"1. Notebook overview","url":"metatron_3.0_Discovery/xml/087_NotebookOutline.html"},{"type":"item","name":"2. Notebook server initial settings","url":"metatron_3.0_Discovery/xml/088_InitialNotebookServerSetting.html"},{"type":"item","name":"3. Create a notebook","url":"metatron_3.0_Discovery/xml/089_CreateaNotebook.html"},{"type":"book","name":"4. Use functions of a notebook","key":"toc30","url":"metatron_3.0_Discovery/xml/090_UseFunctionsofaNotebook.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();