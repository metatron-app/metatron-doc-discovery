(function() {
var toc =  [{"type":"item","name":"4.1 Dashboard list","url":"metatron_3.0_Discovery/xml/063_Dashboardlist.html"},{"type":"book","name":"4.2 Dashboard detail view","key":"toc23","url":"metatron_3.0_Discovery/xml/064_Dashboarddetailview.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();