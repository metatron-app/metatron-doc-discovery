(function() {
var toc =  [{"type":"item","name":"3.5.1 Global variables editing","url":"metatron_3.0_Discovery/xml/103_GlobalVariableEditing.html"},{"type":"item","name":"3.5.2 Query history view","url":"metatron_3.0_Discovery/xml/104_SearchQueryHistoryList.html"},{"type":"item","name":"3.5.3 Workbench navigation","url":"metatron_3.0_Discovery/xml/105_Workbenchnavigation.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();