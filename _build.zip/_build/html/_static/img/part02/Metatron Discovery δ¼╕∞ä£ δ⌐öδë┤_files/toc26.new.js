(function() {
var toc =  [{"type":"item","name":"5.3.1 What is pivoting","url":"metatron_3.0_Discovery/xml/076_Whatispivoting.html"},{"type":"item","name":"5.3.2 Column/row/cross shelves","url":"metatron_3.0_Discovery/xml/077_Theconceptofcolumn.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();