(function() {
var glossary =  {"type":"glossary"};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();