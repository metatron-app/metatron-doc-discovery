(function() {
var toc =  [{"type":"item","name":"4.1.1 View the notebook server list","url":"metatron_3.0_Discovery/xml/033_Searchnotebookserverlist.html"},{"type":"item","name":"4.1.2 Register a new notebook server","url":"metatron_3.0_Discovery/xml/034_Registeranewnotebookserver.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();