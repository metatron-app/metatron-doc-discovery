(function() {
var toc =  [{"type":"item","name":"5.1.1 Log statistics home","url":"metatron_3.0_Discovery/xml/037_Loganalysishomescreen.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();