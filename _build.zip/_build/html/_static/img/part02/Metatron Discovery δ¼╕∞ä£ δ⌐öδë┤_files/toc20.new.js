(function() {
var toc =  [{"type":"item","name":"5.1.1 View the permission schema","url":"metatron_3.0_Discovery/xml/055_Searchpermissionschema.html"},{"type":"item","name":"5.1.2 Change permission schema settings","url":"metatron_3.0_Discovery/xml/056_Changepermissionschemasetting.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();