(function() {
var toc =  [{"type":"item","name":"2.1.1 Data source management home","url":"metatron_3.0_Discovery/xml/011_Datasourcemanagementhomescreen.html"},{"type":"item","name":"2.1.2 Data source details","url":"metatron_3.0_Discovery/xml/012_Datasourcedetails.html"},{"type":"item","name":"2.1.3 Create a data source","url":"metatron_3.0_Discovery/xml/013_Createadatasource.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();