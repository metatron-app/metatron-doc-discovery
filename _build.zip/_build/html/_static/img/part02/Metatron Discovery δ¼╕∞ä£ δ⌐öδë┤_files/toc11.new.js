(function() {
var toc =  [{"type":"book","name":"4.1 Notebook server","key":"toc12","url":"metatron_3.0_Discovery/xml/032_Notebookserver.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();