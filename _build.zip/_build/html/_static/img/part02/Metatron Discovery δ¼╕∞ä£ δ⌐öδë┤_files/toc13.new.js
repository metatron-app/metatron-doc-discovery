(function() {
var toc =  [{"type":"book","name":"5.1 Log Statistics","key":"toc14","url":"metatron_3.0_Discovery/xml/036_Loganalysis.html"},{"type":"book","name":"5.2 Job Log","key":"toc15","url":"metatron_3.0_Discovery/xml/038_Joblog.html"},{"type":"book","name":"5.3 Data Lineage","key":"toc16","url":"metatron_3.0_Discovery/xml/041_Datalineage.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();