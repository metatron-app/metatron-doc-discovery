(function() {
var toc =  [{"type":"book","name":"5.1 Permission schema","key":"toc20","url":"metatron_3.0_Discovery/xml/054_Permissionschema.html"},{"type":"item","name":"5.2 Set shared member & group","url":"metatron_3.0_Discovery/xml/057_Setsharedmembergroup.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();