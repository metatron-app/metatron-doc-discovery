(function() {
var toc =  [{"type":"item","name":"5.5.1 Filters included automatically","url":"metatron_3.0_Discovery/xml/080_Filtersincludedautomatically.html"},{"type":"item","name":"5.5.2 Chart filter panel","url":"metatron_3.0_Discovery/xml/081_Chartfilterpanel.html"},{"type":"item","name":"5.5.3 Chart filter dialog box","url":"metatron_3.0_Discovery/xml/082_Chartfilterdialogbox.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();