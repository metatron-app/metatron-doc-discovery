(function() {
var toc =  [{"type":"item","name":"5.3.1 Data lineage management home","url":"metatron_3.0_Discovery/xml/042_Datalineagemanagementhomescreen.html"},{"type":"item","name":"5.3.2 Data lineage details","url":"metatron_3.0_Discovery/xml/043_Datalineagedetails.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();