(function() {
var toc =  [{"type":"item","name":"5.6.1 Chart style settings menu","url":"metatron_3.0_Discovery/xml/084_Chartstylesettingmenu.html"},{"type":"item","name":"5.6.2 “Common setting” for each chart type","url":"metatron_3.0_Discovery/xml/085_CommonSetting.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();