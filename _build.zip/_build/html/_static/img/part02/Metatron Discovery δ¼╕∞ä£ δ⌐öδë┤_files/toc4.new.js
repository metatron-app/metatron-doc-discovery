(function() {
var toc =  [{"type":"book","name":"2.1 Data Source","key":"toc5","url":"metatron_3.0_Discovery/xml/010_Datasource.html"},{"type":"book","name":"2.2 Data Connection","key":"toc6","url":"metatron_3.0_Discovery/xml/014_Dataconnection.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();