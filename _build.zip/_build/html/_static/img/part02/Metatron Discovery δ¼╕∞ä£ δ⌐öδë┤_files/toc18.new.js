(function() {
var toc =  [{"type":"item","name":"2.1 Composition of the workspace management home","url":"metatron_3.0_Discovery/xml/047_Compositionoftheworkspace.html"},{"type":"item","name":"2.2 Folder items","url":"metatron_3.0_Discovery/xml/048_Folderitem.html"},{"type":"item","name":"2.3 Entity items","url":"metatron_3.0_Discovery/xml/049_Entityitem.html"},{"type":"item","name":"2.4 Clone/move/delete folder and entity","url":"metatron_3.0_Discovery/xml/050_CopyMoveDeletefolderandentity.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();