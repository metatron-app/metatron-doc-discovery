(function() {
var toc =  [{"type":"item","name":"3.3.1 Data snapshot management home","url":"metatron_3.0_Discovery/xml/029_Datasnapshotmanagementhome.html"},{"type":"item","name":"3.3.2 Data snapshot details","url":"metatron_3.0_Discovery/xml/030_Datasnapshotdetails.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();