(function() {
var toc =  [{"type":"item","name":"2.2.1 Data connection management home","url":"metatron_3.0_Discovery/xml/015_Dataconnectionmanagementhome.html"},{"type":"item","name":"2.2.2 Create a new data connection","url":"metatron_3.0_Discovery/xml/016_Createanewdataconnection.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();