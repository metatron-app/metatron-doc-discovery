(function() {
var toc =  [{"type":"item","name":"3.1.1 Dataset management home","url":"metatron_3.0_Discovery/xml/019_Datasetmanagementhome.html"},{"type":"item","name":"3.1.2 Dataset details","url":"metatron_3.0_Discovery/xml/020_Datasetdetails.html"},{"type":"item","name":"3.1.3 Create a new dataset","url":"metatron_3.0_Discovery/xml/021_Createanewdataset.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();